# Smart Notice Banner for WordPress

A lightweight, responsive WordPress announcement banner plugin. Suitable for business websites, Elementor layouts, and WooCommerce stores.

## Features
- Enable/disable the announcement banner
- Change message, CTA text, CTA URL, background color and text color
- Optional dismiss (close) button
- Automatically render at the top of pages on themes supporting `wp_body_open`
- Manual placement using `[smart_notice_banner]` shortcode
- Responsive styling, accessible close control, and escaped output
- No external dependencies

## Installation
1. Download the ZIP from this repository (or upload the plugin folder).
2. In WordPress, go to **Plugins → Add New Plugin → Upload Plugin**.
3. Choose the ZIP, click **Install Now**, then **Activate**.
4. Go to **Settings → Smart Notice Banner**.
5. Configure and click **Save Changes**.

## Shortcode

```
[smart_notice_banner]
```

If using the shortcode, disable **Automatic placement** in settings to prevent duplicate banners.

## Compatibility
- WordPress 6.0+
- PHP 7.4+
- Elementor and Gutenberg via shortcode

## Notes
- Automatic display requires the active theme to call `wp_body_open()`.
- Closing the banner hides that instance for the current page only. It reappears after refresh.
- This is a portfolio/starter project; test it in a staging environment before production use.

## Tech stack
PHP, WordPress Settings API, HTML, CSS, JavaScript.

## License
GPL-2.0-or-later.
